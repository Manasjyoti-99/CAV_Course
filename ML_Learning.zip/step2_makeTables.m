%% STEP 2: Convert YOLO TXT labels -> MATLAB training tables (trainTbl, valTbl)
% YOLO label format per line:
%   classId  x_center  y_center  w  h   (all normalized 0..1)
% We convert to MATLAB boxes [x y w h] in PIXELS, and make a table:
%   imageFilename + one column per class (cell array of boxes)

clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";

trainDir = fullfile(root,"train");
validDir = fullfile(root,"valid");

% ----- Define class names in correct order (ID 0..N-1) -----
% If your dataset has a data.yaml/classes file, we can read it later.
% For now, set these exactly as dataset claims:
classNames = ["Ambulance","Bus","Car","Motorcycle","Truck"];  % classId 0..4

% Build tables
trainTbl = yoloSplitToTrainingTable(trainDir, classNames);
valTbl   = yoloSplitToTrainingTable(validDir, classNames);

disp("Train table columns:");
disp(trainTbl.Properties.VariableNames);

fprintf("Train images: %d\n", height(trainTbl));
fprintf("Val images:   %d\n", height(valTbl));

% Save for next steps
save(fullfile(root,"yolo_tables_carsDetection.mat"), "trainTbl", "valTbl", "classNames");
disp("Saved: yolo_tables_carsDetection.mat");

%% ================= Local function =================
function trainingData = yoloSplitToTrainingTable(splitFolder, classNames)
    imgDir = fullfile(splitFolder,"images");
    labDir = fullfile(splitFolder,"labels");

    if ~isfolder(imgDir) || ~isfolder(labDir)
        error("Expected folders not found. Need images/ and labels/ under: %s", splitFolder);
    end

    % Collect images
    imgFiles = [ ...
        dir(fullfile(imgDir,"*.jpg")); ...
        dir(fullfile(imgDir,"*.jpeg")); ...
        dir(fullfile(imgDir,"*.png")) ];

    if isempty(imgFiles)
        error("No images found in: %s", imgDir);
    end

    % Prepare output table
    imgPaths = strings(numel(imgFiles),1);
    for i = 1:numel(imgFiles)
        imgPaths(i) = fullfile(imgFiles(i).folder, imgFiles(i).name);
    end

    trainingData = table(imgPaths, 'VariableNames', "imageFilename");

    % Create class columns
    classVar = strings(numel(classNames),1);
    for c = 1:numel(classNames)
        classVar(c) = matlab.lang.makeValidName(classNames(c));
        trainingData.(classVar(c)) = cell(height(trainingData),1);
    end

    % Fill boxes per image
    for i = 1:height(trainingData)
        imgPath = string(trainingData.imageFilename(i));
        [~, base, ~] = fileparts(imgPath);
        labPath = fullfile(labDir, base + ".txt");

        % Read image size
        info = imfinfo(imgPath);
        W = info.Width;
        H = info.Height;

        % Init empty boxes for all classes
        for c = 1:numel(classVar)
            trainingData.(classVar(c)){i} = zeros(0,4); % [x y w h]
        end

        % Some datasets may have images without labels (no txt file)
        if ~isfile(labPath)
            continue;
        end

        % Read YOLO label file
        lines = readlines(labPath);
        lines = strtrim(lines);
        lines(lines=="") = [];

        for j = 1:numel(lines)
            parts = split(lines(j));
            parts(parts=="") = [];

            if numel(parts) < 5
                continue;
            end

            cls = str2double(parts(1));      % classId (0-based)
            xc  = str2double(parts(2));
            yc  = str2double(parts(3));
            bw  = str2double(parts(4));
            bh  = str2double(parts(5));

            if isnan(cls) || isnan(xc) || isnan(yc) || isnan(bw) || isnan(bh)
                continue;
            end

            clsIdx = cls + 1; % convert 0-based -> 1-based indexing
            if clsIdx < 1 || clsIdx > numel(classVar)
                continue;
            end

            % Convert normalized YOLO -> pixel [x y w h]
            boxW = bw * W;
            boxH = bh * H;
            x = (xc * W) - boxW/2;
            y = (yc * H) - boxH/2;

            % Clip to image boundaries (optional but safer)
            x = max(0, x);
            y = max(0, y);
            boxW = min(boxW, W - x);
            boxH = min(boxH, H - y);

            trainingData.(classVar(clsIdx)){i}(end+1,:) = [x y boxW boxH]; %#ok<AGROW>
        end
    end
end
