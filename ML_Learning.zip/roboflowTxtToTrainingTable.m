function trainingData = roboflowTxtToTrainingTable(splitFolder)
% Parse Roboflow _annotations.txt format:
% filename xmin,ymin,xmax,ymax,classId [repeat...]
% Converts to MATLAB training table:
% imageFilename + one column per class with boxes [x y w h].

    annPath = fullfile(splitFolder, "_annotations.txt");
    clsPath = fullfile(splitFolder, "_classes.txt");

    if ~isfile(annPath)
        error("Missing _annotations.txt in: %s", splitFolder);
    end
    if ~isfile(clsPath)
        error("Missing _classes.txt in: %s", splitFolder);
    end

    % ---- read class names (line i = class ID i-1) ----
    clsLines = readlines(clsPath);
    clsLines = strtrim(clsLines);
    clsLines(clsLines=="") = [];
    % If file has a header like "classes", remove non-class lines if needed:
    % (Usually Roboflow _classes.txt is just a clean list.)
    classNames = clsLines;
    classNames = string(classNames);

    % Make valid MATLAB variable names for columns
    classVarNames = strings(numel(classNames),1);
    for i = 1:numel(classNames)
        classVarNames(i) = matlab.lang.makeValidName(classNames(i));
    end

    % ---- read annotations file line-by-line ----
    fid = fopen(annPath,'r');
    if fid < 0
        error("Could not open: %s", annPath);
    end

    imageList = strings(0);
    boxMap = containers.Map('KeyType','char','ValueType','any');

    while true
        line = fgetl(fid);
        if ~ischar(line); break; end
        line = strtrim(line);
        if line == ""; continue; end

        parts = split(string(line), " ");
        parts(parts=="") = [];

        % first token is filename
        fname = parts(1);
        imgPath = fullfile(splitFolder, fname);

        if ~isKey(boxMap, char(imgPath))
            % initialize per-class cell for this image
            perClass = cell(numel(classNames),1);
            for c = 1:numel(classNames)
                perClass{c} = zeros(0,4); % [x y w h]
            end
            boxMap(char(imgPath)) = perClass;
            imageList(end+1,1) = imgPath; %#ok<AGROW>
        end

        perClass = boxMap(char(imgPath));

        % remaining tokens are boxes
        for t = 2:numel(parts)
            token = strtrim(parts(t));
            if token == ""; continue; end

            nums = sscanf(token, "%f,%f,%f,%f,%f");
            if numel(nums) ~= 5
                continue; % skip any weird token
            end
            xmin = nums(1); ymin = nums(2);
            xmax = nums(3); ymax = nums(4);
            classId = nums(5);

            % Roboflow classId is typically 0-based OR 1-based depending on export.
            % From your sample: classId includes 1..4 etc. We'll assume 1-based.
            % If you ever see classId==0, we will switch to 0-based adjustment.
            if classId == 0
                % treat as 0-based -> shift by +1
                idx = classId + 1;
            else
                idx = classId; % 1-based
            end

            if idx < 1 || idx > numel(classNames)
                continue;
            end

            w = xmax - xmin;
            h = ymax - ymin;
            perClass{idx}(end+1,:) = [xmin ymin w h]; %#ok<AGROW>
        end

        boxMap(char(imgPath)) = perClass;
    end

    fclose(fid);

    % ---- build output table ----
    trainingData = table(imageList, 'VariableNames', "imageFilename");

    for c = 1:numel(classVarNames)
        trainingData.(classVarNames(c)) = cell(height(trainingData),1);
    end

    for i = 1:height(trainingData)
        perClass = boxMap(char(trainingData.imageFilename(i)));
        for c = 1:numel(classVarNames)
            trainingData.(classVarNames(c)){i} = perClass{c};
        end
    end

    % check missing images
    missing = ~isfile(trainingData.imageFilename);
    if any(missing)
        warning("Some images referenced in _annotations.txt are missing. Example: %s", ...
            trainingData.imageFilename(find(missing,1)));
    end

    % return also class names? (we'll infer from table later)
end
