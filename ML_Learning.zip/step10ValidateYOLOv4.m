%% STEP 10: Test on VALID split (Ground Truth vs Prediction)
clear; clc; close all;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";

% Load trained detector (epoch20 continuation output)
load(fullfile(root,"yolo_detector_trained_epoch20.mat"), "detector20");
detector = detector20;

% Load validation table (ground truth)
load(fullfile(root,"yolo_tables_carsDetection.mat"), "valTbl", "classNames"); %#ok<NASGU>

% Identify box columns (one column per class)
boxCols = valTbl.Properties.VariableNames;
boxCols = boxCols(~strcmp(boxCols,"imageFilename"));

% Settings
threshold = 0.05;   % from your sweep: better recall than 0.20/0.30
topK = 8;            % show only top-K predictions (keeps image clean)
nShow = 10;          % number of images to inspect

rng(10);
idx = randperm(height(valTbl), min(nShow, height(valTbl)));

for n = 1:numel(idx)
    i = idx(n);
    imgPath = string(valTbl.imageFilename(i));
    I = imread(imgPath);

    % -------- Ground Truth (from valTbl) --------
    gtBoxes = [];
    gtLabels = strings(0);

    for k = 1:numel(boxCols)
        B = valTbl.(boxCols{k}){i};   % [x y w h] for that class
        if ~isempty(B)
            gtBoxes  = [gtBoxes; B]; %#ok<AGROW>
            gtLabels = [gtLabels; repmat(string(boxCols{k}), size(B,1), 1)]; %#ok<AGROW>
        end
    end

    Igt = I;
    if ~isempty(gtBoxes)
        Igt = insertObjectAnnotation(Igt, "rectangle", gtBoxes, gtLabels);
    end

    % -------- Prediction --------
    [bboxes, scores, labels] = detect(detector, I, "Threshold", threshold);

    % Keep only topK predictions (by score)
    if ~isempty(scores)
        [scores, order] = sort(scores, "descend");
        order = order(1:min(topK, numel(order)));
        bboxes = bboxes(order,:);
        scores = scores(1:numel(order));
        labels = labels(order);

        predText = string(labels) + " : " + string(round(scores,2));
        Ipred = insertObjectAnnotation(I, "rectangle", bboxes, predText);
    else
        Ipred = I; % no detections
    end

    % -------- Display side-by-side --------
    figure(1); clf;
    tiledlayout(1,2,"Padding","compact","TileSpacing","compact");

    nexttile; imshow(Igt);
    title("VALID: Ground Truth");

    nexttile; imshow(Ipred);
    title(sprintf("VALID: Prediction (Thr=%.2f, TopK=%d)", threshold, topK));

    sgtitle(sprintf("Image %d/%d | %s", n, numel(idx), imgPath), "Interpreter","none");

    disp("Press Enter for next image...");
    pause;
end