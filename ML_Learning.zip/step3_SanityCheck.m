%% STEP 3: Sanity check - show 10 random images with ground-truth boxes + labels
clear; clc; close all;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_tables_carsDetection.mat"), "trainTbl", "classNames");

% class columns in the table (everything except imageFilename)
boxCols = trainTbl.Properties.VariableNames;
boxCols = boxCols(~strcmp(boxCols,"imageFilename"));

% pick only rows that have at least one box
hasAny = false(height(trainTbl),1);
for i = 1:height(trainTbl)
    for k = 1:numel(boxCols)
        if ~isempty(trainTbl.(boxCols{k}){i})
            hasAny(i) = true;
            break;
        end
    end
end

idxPool = find(hasAny);
if isempty(idxPool)
    error("No labeled images found in trainTbl. Step 2 may not have parsed labels correctly.");
end

nShow = min(10, numel(idxPool));
rng(0);
pick = idxPool(randperm(numel(idxPool), nShow));

% Show one-by-one (press Enter in Command Window to move to next)
for n = 1:nShow
    i = pick(n);

    imgPath = string(trainTbl.imageFilename(i));
    I = imread(imgPath);

    allBoxes  = [];
    allLabels = strings(0);

    for k = 1:numel(boxCols)
        B = trainTbl.(boxCols{k}){i}; % [x y w h]
        if ~isempty(B)
            allBoxes  = [allBoxes; B]; %#ok<AGROW>
            allLabels = [allLabels; repmat(string(boxCols{k}), size(B,1), 1)]; %#ok<AGROW>
        end
    end

    I2 = insertObjectAnnotation(I, "rectangle", allBoxes, allLabels);

    figure(1); imshow(I2);
    title(sprintf("Step 3 Audit %d/%d | Row %d", n, nShow, i), "Interpreter","none");

    fprintf("\n[%d/%d] %s\n", n, nShow, imgPath);
    fprintf("Labels shown: %s\n", strjoin(unique(allLabels)', ", "));

    % Wait for your inspection
    disp("Press Enter in the Command Window to show the next image...");
    pause;
end

disp("Step 3 audit finished.");
