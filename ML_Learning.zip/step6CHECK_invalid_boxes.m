%% CHECK: Find invalid boxes that can cause NaN/Inf during training
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_tables_carsDetection.mat"), "trainTbl");

boxCols = trainTbl.Properties.VariableNames;
boxCols = boxCols(~strcmp(boxCols,"imageFilename"));

badCount = 0;
examples = [];

for i = 1:height(trainTbl)
    imgPath = string(trainTbl.imageFilename(i));
    info = imfinfo(imgPath);
    W = info.Width; H = info.Height;

    for k = 1:numel(boxCols)
        B = trainTbl.(boxCols{k}){i}; % [x y w h]
        if isempty(B); continue; end

        % checks
        bad = any(isnan(B),2) | any(isinf(B),2) | (B(:,3) <= 0) | (B(:,4) <= 0) | ...
              (B(:,1) < 0) | (B(:,2) < 0) | ...
              (B(:,1)+B(:,3) > W+1) | (B(:,2)+B(:,4) > H+1);

        if any(bad)
            badCount = badCount + sum(bad);
            if size(examples,1) < 10
                examples = [examples; [i, k, find(bad,1)]]; %#ok<AGROW>
            end
        end
    end
end

fprintf("Total invalid boxes found: %d\n", badCount);
if ~isempty(examples)
    disp("Example [rowIndex, classColumnIndex, boxIndexInThatCell]:");
    disp(examples);
else
    disp("No invalid boxes detected.");
end
